# CineTranslate Voice (Telugu -> English) - 프로젝트 설명 (తెలుగు)

ఈ ప్రాజెక్ట్ లో:
- వీడియో ప్లేయర్ (network sample)
- సబ్‌టైటిల్(SRT) లొడింగ్
- వాయిస్-టు-టెక్స్ట్ (స్పీచ్_TO_TEXT plugin) - డివైస్ STT వినియోగిస్తుంది (Telugu locale)
- ఆ recognized టెక్స్ట్‌ను ఆన్‌లైన్‌లో LibreTranslate (https://libretranslate.de) తో English గా మార్చి స్క్రీన్ పై చూపిస్తుంది.

## ముఖ్యమైన గమనికలు (APK బిల్డ్ కోసం)
Flutter ప్రాజెక్ట్ లో ANDROID/IOS ఫోల్డర్‌లు లేవు. మీరు APK తీయడానికి:
1. ఈ ఫోల్డర్ లో టెర్మినల్ ఓపెన్ చేసి:
   ```
   flutter create .
   ```
   ఇది android/, ios/ ఫోల్డర్లు క్రియేట్ చేస్తుంది.
2. AndroidManifest.xml లో microphone permission జోడించండి:
   `android/app/src/main/AndroidManifest.xml` లో `<manifest>` ట్యాగ్ లో:
   ```xml
   <uses-permission android:name="android.permission.RECORD_AUDIO"/>
   <uses-permission android:name="android.permission.INTERNET"/>
   ```
3. Android targetSdkVersion/compileSdkVersion మీ ఫ్లట్టర్ ప్లిక్‌ను అనుసరించండి (flutter doctor సూచనలు చూడండి).
4. డిపెండెన్సీలు ఇన్స్టాల్ చేయండి:
   ```
   flutter pub get
   ```
5. APK తయారుచేయండి:
   ```
   flutter build apk --release
   ```
   లేదా డెవ్ కోసం:
   ```
   flutter run
   ```

## ట్రాన్స్‌లేట్ మోడ్ మార్చడం
- డిఫాల్ట్: LibreTranslate (mode='libreTranslate') ఉపయోగిస్తుంది.
- మీరు Google Cloud Translate ఉపయోగించాలని ఉంటే, `lib/services/translation_service.dart` లో mode='backend' పెట్టి మీ బ్యాక్‌ఎండ్ URL ఇవ్వండి.

## పరికర అనుమతులు
- Speech-to-text కోసం మైక్రోఫోన్ అనుమతి అవసరం (AndroidManifest లో జోడించాలి).
- కొన్ని పరికరాల్లో Telugu locale అందుబాటులో లేకపోవచ్చు; ఆ సందర్భాల్లో STT పరి��త ఫలితం ఇవ్వకపోవచ్చు.

## ఉపయోగం
1. `flutter create .`
2. `flutter pub get`
3. `flutter run`
4. ప్లే చేసేవేళ audio మైక్ బటన్ నొక్కి మాట్లాడండి (Telugu), recognized text translate అవి స్క్రీన్ పై చూపిస్తుంది.

