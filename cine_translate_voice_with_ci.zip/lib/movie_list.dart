// movie_list.dart
import 'package:flutter/material.dart';
import 'movie_player.dart';

class MovieListPage extends StatelessWidget {
  final List<Map<String, String>> movies = [
    {
      'title': 'Big Buck Bunny (sample)',
      'videoUrl': 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
      'subtitle': 'assets/sample_subtitles.srt'
    }
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('CineTranslate Voice')),
      body: ListView.builder(
        itemCount: movies.length,
        itemBuilder: (context, i) {
          final m = movies[i];
          return ListTile(
            leading: Icon(Icons.movie),
            title: Text(m['title']!),
            subtitle: Text('Tap to play and try voice translate (Telugu -> English)'),
            onTap: () {
              Navigator.push(context, MaterialPageRoute(
                builder: (_) => MoviePlayerPage(videoUrl: m['videoUrl']!, subtitleAsset: m['subtitle']!)
              ));
            },
          );
        },
      ),
    );
  }
}
