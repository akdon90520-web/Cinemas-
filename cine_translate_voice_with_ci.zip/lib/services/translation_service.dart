// translation_service.dart
// డీఫాల్ట్‌గా LibreTranslate (https://libretranslate.de) వాడుతుంది.
// మీరు కావాలంటే గూగుల్ ట్రాన్స్‌లేట్ లేదా బ్యాక్‌ఎండ్ ఉపయోగించవచ్చు.
import 'dart:convert';
import 'package:http/http.dart' as http;

class TranslationService {
  final String mode; // 'offlineDemo' | 'libreTranslate' | 'backend'
  final String backendUrl;
  final String libreTranslateUrl;

  TranslationService({this.mode = 'libreTranslate', this.backendUrl = '', this.libreTranslateUrl = 'https://libretranslate.de/translate'});

  Future<List<String>> translateLines(List<String> lines) async {
    if (mode == 'offlineDemo') {
      return lines.map((l) => _offlineDemo(l)).toList();
    } else if (mode == 'libreTranslate') {
      final List<String> out = [];
      for (String line in lines) {
        final resp = await http.post(Uri.parse(libreTranslateUrl),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({'q': line, 'source': 'auto', 'target': 'en', 'format': 'text'}));
        if (resp.statusCode == 200) {
          final j = jsonDecode(resp.body);
          out.add(j['translatedText'] ?? '');
        } else {
          out.add('[translation_error]');
        }
      }
      return out;
    } else if (mode == 'backend') {
      final resp = await http.post(Uri.parse(backendUrl),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({'target': 'en', 'lines': lines}));
      if (resp.statusCode == 200) {
        final j = jsonDecode(resp.body);
        return List<String>.from(j['translations']);
      } else {
        throw Exception('Backend translation error: \${resp.body}');
      }
    } else {
      throw Exception('Unknown mode');
    }
  }

  String _offlineDemo(String txt) {
    var s = txt;
    final map = {'ఇది':'This','నేను':'I','వస్తున్నాను':'am coming','హలో':'Hello'};
    map.forEach((k,v){ s = s.replaceAll(k,v); });
    if (s == txt) return '[en demo] ' + txt;
    return s;
  }
}
