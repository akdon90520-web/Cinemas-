// subtitle_service.dart - SRT parser and helper functions
import 'package:flutter/services.dart';
import '../models/subtitle_line.dart';

List<String> _splitTimestamp(String ts) => ts.split(' --> ');

Duration _parseDuration(String s) {
  final parts = s.split(':');
  final hours = int.parse(parts[0]);
  final minutes = int.parse(parts[1]);
  final secParts = parts[2].split(',');
  final seconds = int.parse(secParts[0]);
  final ms = int.parse(secParts[1]);
  return Duration(hours: hours, minutes: minutes, seconds: seconds, milliseconds: ms);
}

Future<List<SubtitleLine>> parseSrtFromAsset(String assetPath) async {
  final raw = await rootBundle.loadString(assetPath);
  return parseSrt(raw);
}

List<SubtitleLine> parseSrt(String raw) {
  final lines = raw.replaceAll('\r', '').split('\n');
  final List<SubtitleLine> out = [];
  int i = 0;
  while (i < lines.length) {
    if (lines[i].trim().isEmpty) { i++; continue; }
    final idx = int.tryParse(lines[i].trim());
    if (idx == null) { i++; continue; }
    final timeLine = lines[i + 1];
    final times = _splitTimestamp(timeLine);
    final start = _parseDuration(times[0].trim());
    final end = _parseDuration(times[1].trim());
    final buffer = StringBuffer();
    int j = i + 2;
    while (j < lines.length && lines[j].trim().isNotEmpty) {
      buffer.writeln(lines[j]);
      j++;
    }
    out.add(SubtitleLine(index: idx, start: start, end: end, text: buffer.toString().trim()));
    i = j + 1;
  }
  return out;
}

String subtitleLinesToSrt(List<SubtitleLine> lines) {
  final sb = StringBuffer();
  for (var l in lines) {
    String twoDigits(int n) => n.toString().padLeft(2, '0');
    String threeDigits(int n) => n.toString().padLeft(3, '0');
    String durToStr(Duration d) {
      final hh = twoDigits(d.inHours);
      final mm = twoDigits(d.inMinutes.remainder(60));
      final ss = twoDigits(d.inSeconds.remainder(60));
      final ms = threeDigits(d.inMilliseconds.remainder(1000));
      return '\$hh:\$mm:\$ss,\$ms';
    }
    sb.writeln(l.index);
    sb.writeln('\${durToStr(l.start)} --> \${durToStr(l.end)}');
    sb.writeln(l.text);
    sb.writeln();
  }
  return sb.toString();
}
