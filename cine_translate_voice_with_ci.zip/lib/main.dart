// main.dart -- CineTranslate Voice (Telugu comments)
// ఇది యాప్ ప్రవేశం. MovieListPage నుంచి స్టార్ట్ అవుతుంది.
import 'package:flutter/material.dart';
import 'movie_list.dart';

void main() {
  runApp(CineTranslateApp());
}

class CineTranslateApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'CineTranslate Voice',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(),
      home: MovieListPage(),
    );
  }
}
