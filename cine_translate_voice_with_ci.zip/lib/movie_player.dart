// movie_player.dart
// ఇది వీడియో ప్లేయర్ UI, సబ్‌టైటిల్ ప్రదర్శన, మరియు వాయిస్-టు-టెక్స్ట్ + ట్రాన్స్‌లేట్ బటన్ కలిగిన స్క్రీన్.
import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'services/subtitle_service.dart';
import 'services/translation_service.dart';
import 'models/subtitle_line.dart';
import 'package:path_provider/path_provider.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

class MoviePlayerPage extends StatefulWidget {
  final String videoUrl;
  final String subtitleAsset;

  MoviePlayerPage({required this.videoUrl, required this.subtitleAsset});

  @override
  State<MoviePlayerPage> createState() => _MoviePlayerPageState();
}

class _MoviePlayerPageState extends State<MoviePlayerPage> {
  late VideoPlayerController _controller;
  List<SubtitleLine> originalSubs = [];
  List<SubtitleLine> translatedSubs = [];
  bool translatedLoaded = false;
  bool showTranslated = false;
  Timer? _timer;

  // Speech-to-text controller (for capturing Telugu voice)
  late stt.SpeechToText _speech;
  bool _isListening = false;
  String _lastRecognized = '';

  // Translation service: default uses libretranslate (online)
  final TranslationService translator = TranslationService(mode: 'libreTranslate');

  @override
  void initState() {
    super.initState();
    _speech = stt.SpeechToText();
    _controller = VideoPlayerController.network(widget.videoUrl)
      ..initialize().then((_) {
        setState(() {});
        _controller.play();
      });
    _loadSubtitles();
    _timer = Timer.periodic(Duration(milliseconds: 300), (_) { setState(() {}); });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _controller.dispose();
    super.dispose();
  }

  Future<void> _loadSubtitles() async {
    originalSubs = await parseSrtFromAsset(widget.subtitleAsset);
    setState(() {});
  }

  // Voice capture: listens, converts speech->text (Telugu), then translates to English and shows as subtitle.
  Future<void> _startListeningAndTranslate() async {
    bool available = await _speech.initialize(
      onStatus: (s) => print('STT status: \$s'),
      onError: (e) => print('STT error: \$e'),
    );
    if (!available) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Speech recognition not available')));
      return;
    }
    setState(() { _isListening = true; _lastRecognized = ''; });
    await _speech.listen(
      localeId: 'te_IN', // Telugu locale - may vary by device
      onResult: (result) async {
        if (result.finalResult) {
          final recognized = result.recognizedWords;
          setState(() { _lastRecognized = recognized; _isListening = false; });
          // Translate recognized Telugu text to English (online)
          try {
            final translations = await translator.translateLines([recognized]);
            final translated = translations.isNotEmpty ? translations[0] : '[translation error]';
            // Show translated text as a temporary subtitle overlay (append to translatedSubs with current timestamp)
            final pos = _controller.value.position;
            final newSub = SubtitleLine(index: translatedSubs.length + 1000, start: pos, end: pos + Duration(seconds: 4), text: translated);
            translatedSubs.add(newSub);
            setState(() { showTranslated = true; translatedLoaded = true; });
          } catch (e) {
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Translation failed: \$e')));
          }
        }
      }
    );
  }

  Future<void> _stopListening() async {
    await _speech.stop();
    setState(() { _isListening = false; });
  }

  String? _currentSubtitle() {
    if (!_controller.value.isInitialized) return null;
    final pos = _controller.value.position;
    final list = showTranslated ? translatedSubs : originalSubs;
    for (var l in list) {
      if (pos >= l.start && pos <= l.end) return l.text;
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    final subtitleText = _currentSubtitle();
    return Scaffold(
      appBar: AppBar(title: Text('Player')),
      body: Column(
        children: [
          if (_controller.value.isInitialized)
            AspectRatio(
              aspectRatio: _controller.value.aspectRatio,
              child: Stack(
                children: [
                  VideoPlayer(_controller),
                  if (subtitleText != null)
                    Positioned(
                      left: 12, right: 12, bottom: 20,
                      child: Container(
                        padding: EdgeInsets.symmetric(vertical: 8, horizontal: 10),
                        color: Colors.black54,
                        child: Text(subtitleText, textAlign: TextAlign.center, style: TextStyle(fontSize: 16)),
                      ),
                    )
                ],
              ),
            )
          else
            Container(height: 220, child: Center(child: CircularProgressIndicator())),
          SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              IconButton(
                icon: Icon(_controller.value.isPlaying ? Icons.pause : Icons.play_arrow),
                onPressed: () { setState(() { _controller.value.isPlaying ? _controller.pause() : _controller.play(); }); },
                iconSize: 36,
              ),
              SizedBox(width: 8),
              ElevatedButton.icon(
                onPressed: _isListening ? _stopListening : _startListeningAndTranslate,
                icon: Icon(_isListening ? Icons.mic : Icons.mic_none),
                label: Text(_isListening ? 'Listening...' : 'Speak (Telugu) → Translate'),
              ),
              SizedBox(width: 8),
              ElevatedButton.icon(
                onPressed: () async {
                  // Pre-translate all subtitle lines to English (batch) and show
                  if (originalSubs.isEmpty) return;
                  try {
                    final texts = originalSubs.map((e) => e.text).toList();
                    final translated = await translator.translateLines(texts);
                    translatedSubs = List.generate(originalSubs.length, (i) {
                      final orig = originalSubs[i];
                      return SubtitleLine(index: orig.index, start: orig.start, end: orig.end, text: translated[i]);
                    });
                    setState(() { translatedLoaded = true; showTranslated = true; });
                  } catch (e) {
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Batch translation failed: \$e')));
                  }
                },
                icon: Icon(Icons.translate),
                label: Text('Translate Subtitles'),
              ),
            ],
          ),
          SizedBox(height: 8),
          if (_lastRecognized.isNotEmpty) Padding(
            padding: const EdgeInsets.symmetric(horizontal:12.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Recognized (Telugu):', style: TextStyle(fontSize: 12, color: Colors.white70)),
                Text(_lastRecognized),
              ],
            ),
          ),
          SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal:12.0),
            child: Text('Note: uses device STT and online translation (LibreTranslate). Check README for permissions and building APK.', style: TextStyle(fontSize: 12, color: Colors.white70)),
          )
        ],
      ),
    );
  }
}
